import React, { useState, useEffect } from 'react';
import { TestConfig, GeneratedTest, Question } from './types';
import { createDefaultTest, calculateMatrixAndSummary, ensureUniqueDiagramsInTest, alignQuestionsToOutcomeMatrix, sanitizeQuestionMath } from './utils/testGenerator';
import { exportTestToWord } from './utils/wordExporter';
import { MATH_12_SYLLABUS } from './data/math12Syllabus';
import { HeaderMenu } from './components/HeaderMenu';
import { QuestionGeneratorModal } from './components/QuestionGeneratorModal';
import { QuestionList } from './components/QuestionList';
import { MatrixTable } from './components/MatrixTable';
import { SlideViewer } from './components/SlideViewer';
import { EditorModal } from './components/EditorModal';
import { FileUploadModal } from './components/FileUploadModal';
import { AssistantChat } from './components/AssistantChat';
import { TestBankModal } from './components/TestBankModal';
import {
  getStoredTestBank,
  saveTestToBank,
  extractTestMetadata,
  findDuplicateStoredTest,
  generateSequencedFileName,
  updateStoredTest,
  formatStandardTestFileName,
  StoredTestItem,
} from './utils/testBankStorage';
import { DuplicatePromptModal } from './components/DuplicatePromptModal';
import { CheckCircle2, Sparkles, FolderArchive } from 'lucide-react';

function ensureUniqueQuestionIds(questions: Question[]): Question[] {
  if (!Array.isArray(questions)) return [];
  const seen = new Set<string>();
  return questions.map((q, idx) => {
    let uniqueId = q.id || `q_${idx + 1}_${Date.now()}`;
    if (seen.has(uniqueId)) {
      uniqueId = `${uniqueId}_dup_${idx + 1}_${Math.random().toString(36).slice(2, 6)}`;
    }
    seen.add(uniqueId);
    return { ...q, id: uniqueId };
  });
}

export default function App() {
  const [testConfig, setTestConfig] = useState<TestConfig>({
    mode: 'kt_dinh_ky',
    title: 'ĐỀ KIỂM TRA ĐỊNH KỲ MÔN TOÁN LỚP 12',
    schoolName: 'TRƯỜNG THPT MAI THANH THẾ',
    departmentName: 'TỔ TOÁN',
    academicYear: '2026 - 2027',
    durationMinutes: 45,
    selectedTopicIds: ['topic_dao_ham'],
    selectedLessonId: 'lesson_don_dieu',
    counts: {
      multipleChoice: { nhanBiet: 3, thongHieu: 2, vanDung: 1 },
      trueFalse: { nhanBiet: 0, thongHieu: 1, vanDung: 1 },
      shortAnswer: { nhanBiet: 0, thongHieu: 1, vanDung: 1 },
    },
  });

  const [hasGenerated, setHasGenerated] = useState<boolean>(false);

  const [currentTest, setCurrentTest] = useState<GeneratedTest>(() => {
    try {
      const saved = localStorage.getItem('math12_question_bank_test');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.questions) && parsed.questions.length > 0) {
          const uniqueQs = ensureUniqueQuestionIds(parsed.questions);
          const updatedConfig = {
            ...parsed.config,
            academicYear:
              parsed.config?.academicYear &&
              parsed.config.academicYear !== '2025 - 2026' &&
              parsed.config.academicYear !== '2024 - 2025'
                ? parsed.config.academicYear
                : '2026 - 2027',
          };
          return { ...parsed, config: updatedConfig, questions: uniqueQs };
        }
      }
    } catch (e) {
      console.warn('Could not load stored question bank:', e);
    }
    return createDefaultTest(testConfig);
  });

  // Sync testConfig changes (e.g. academicYear, title, schoolName) to currentTest in real-time
  useEffect(() => {
    setCurrentTest((prev) => ({
      ...prev,
      config: {
        ...prev.config,
        academicYear: testConfig.academicYear,
        schoolName: testConfig.schoolName,
        departmentName: testConfig.departmentName,
        title: testConfig.title,
        durationMinutes: testConfig.durationMinutes,
      },
    }));
  }, [
    testConfig.academicYear,
    testConfig.schoolName,
    testConfig.departmentName,
    testConfig.title,
    testConfig.durationMinutes,
  ]);

  useEffect(() => {
    try {
      localStorage.setItem('math12_question_bank_test', JSON.stringify(currentTest));
    } catch (e) {
      console.warn('Could not persist question bank:', e);
    }
  }, [currentTest]);

  const [activeTab, setActiveTab] = useState<'generator' | 'slides' | 'editor' | 'matrix' | 'bank'>('generator');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [savedCount, setSavedCount] = useState<number>(() => {
    try {
      return getStoredTestBank().length;
    } catch {
      return 0;
    }
  });

  // Duplicate prompt modal state for auto-save
  const [duplicatePromptState, setDuplicatePromptState] = useState<{
    isOpen: boolean;
    pendingTest: GeneratedTest | null;
    duplicateItem: StoredTestItem | null;
    proposedBaseFileName: string;
    nextSequencedFileName: string;
  }>({
    isOpen: false,
    pendingTest: null,
    duplicateItem: null,
    proposedBaseFileName: '',
    nextSequencedFileName: '',
  });

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  /**
   * Automatically saves newly created test to the bank.
   * If a duplicate filename/test is found, prompts the user.
   * If confirmed, saves as a new version with sequential suffix (e.g. _1, _2...).
   */
  const handleAutoSaveNewTest = (testToSave: GeneratedTest) => {
    try {
      const meta = extractTestMetadata(testToSave);
      const baseFileName = formatStandardTestFileName(meta.grade, meta.topicName, meta.lessonName, true);
      const duplicate = findDuplicateStoredTest(baseFileName, meta.topicName, meta.lessonName);

      if (duplicate) {
        // Found collision -> Prompt user
        const nextSeqName = generateSequencedFileName(baseFileName);
        setDuplicatePromptState({
          isOpen: true,
          pendingTest: testToSave,
          duplicateItem: duplicate,
          proposedBaseFileName: baseFileName,
          nextSequencedFileName: nextSeqName,
        });
      } else {
        // No collision -> Auto save directly
        const saved = saveTestToBank(testToSave);
        setSavedCount(getStoredTestBank().length);
        showNotification(`💾 Đã tự động lưu đề vào kho: "${saved.fileName}.docx"!`);
      }
    } catch (err) {
      console.error('Error in auto-saving test to bank:', err);
    }
  };

  // User chooses to continue saving with sequential suffix added (_1, _2, ...)
  const handleConfirmSaveSequenced = () => {
    if (!duplicatePromptState.pendingTest) {
      setDuplicatePromptState((prev) => ({ ...prev, isOpen: false }));
      return;
    }
    try {
      const saved = saveTestToBank(duplicatePromptState.pendingTest, {
        allowDuplicateSequence: true,
      });
      setSavedCount(getStoredTestBank().length);
      showNotification(`💾 Đã lưu vào kho đề với phiên bản mới: "${saved.fileName}.docx"!`);
    } catch (err) {
      console.error('Error saving sequenced test:', err);
      showNotification('❌ Có lỗi khi lưu đề thi.');
    } finally {
      setDuplicatePromptState({
        isOpen: false,
        pendingTest: null,
        duplicateItem: null,
        proposedBaseFileName: '',
        nextSequencedFileName: '',
      });
    }
  };

  const handleCancelDuplicatePrompt = () => {
    setDuplicatePromptState({
      isOpen: false,
      pendingTest: null,
      duplicateItem: null,
      proposedBaseFileName: '',
      nextSequencedFileName: '',
    });
    showNotification('ℹ️ Đã hủy lưu đề thi vào kho.');
  };

  // Quick save current test directly into the storage bank
  const handleQuickSaveCurrentTest = () => {
    handleAutoSaveNewTest(currentTest);
  };

  // Load a test from the storage bank into active workspace
  const handleLoadTestFromBank = (loadedTest: GeneratedTest) => {
    setCurrentTest(loadedTest);
    setTestConfig(loadedTest.config);
    setHasGenerated(true);
    setActiveTab('generator');
    showNotification(`🚀 Đã mở đề "${loadedTest.config.title}" vào bàn làm việc!`);
  };

  // Main generation handler: Clears and completely renews questions & matrix
  const handleGenerateQuestions = async (promptOverride?: string) => {
    setIsGenerating(true);

    const selectedTopics = MATH_12_SYLLABUS.filter((t) =>
      testConfig.selectedTopicIds.includes(t.id)
    );
    const effectiveTopics = selectedTopics.length > 0 ? selectedTopics : [MATH_12_SYLLABUS[0]];

    const selectedTopicNames = effectiveTopics.map((t) => t.name);

    const allLessonsInSelectedTopics = effectiveTopics.flatMap((t) => t.lessons);

    const selectedLessons =
      testConfig.selectedLessonIds && testConfig.selectedLessonIds.length > 0
        ? allLessonsInSelectedTopics.filter((l) => testConfig.selectedLessonIds!.includes(l.id))
        : testConfig.selectedLessonId
        ? allLessonsInSelectedTopics.filter((l) => l.id === testConfig.selectedLessonId)
        : allLessonsInSelectedTopics;

    const effectiveLessons = selectedLessons.length > 0 ? selectedLessons : allLessonsInSelectedTopics;
    const primaryTopic = effectiveTopics[0];
    const targetLesson = effectiveLessons[0];

    const selectedLessonNames = effectiveLessons.map((l) => l.name);
    const selectedLessonName = selectedLessonNames.join('; ');

    const selectedOutcomes =
      testConfig.selectedOutcomes && testConfig.selectedOutcomes.length > 0
        ? testConfig.selectedOutcomes
        : effectiveLessons.flatMap((l) => l.outcomes);

    const payloadConfig = {
      ...testConfig,
      selectedTopicNames,
      selectedLessonName,
      selectedLessonNames,
      selectedOutcomes,
    };

    try {
      const response = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          config: payloadConfig,
          promptOverride,
        }),
      });

      const result = await response.json();

      if (result.success && result.data && result.data.questions && result.data.questions.length > 0) {
        const newQuestions: Question[] = result.data.questions.map((q: any, idx: number) => {
          let outcomeIdx = typeof q.learningOutcomeIndex === 'number' ? q.learningOutcomeIndex : -1;
          if (outcomeIdx < 0 && q.learningOutcome && selectedOutcomes.length > 0) {
            const foundIdx = selectedOutcomes.findIndex((so: string) =>
              so.toLowerCase().includes(q.learningOutcome.toLowerCase()) ||
              q.learningOutcome.toLowerCase().includes(so.toLowerCase())
            );
            if (foundIdx >= 0) outcomeIdx = foundIdx;
          }
          if (outcomeIdx < 0) {
            outcomeIdx = selectedOutcomes.length > 0 ? idx % selectedOutcomes.length : 0;
          }
          const chosenOutcome = selectedOutcomes[outcomeIdx] || q.learningOutcome || selectedOutcomes[0] || 'Đạt yêu cầu GDPT 2018';

          let rawQ: Question;
          if (q.type === 'true_false') {
            rawQ = {
              id: q.id || `gen_q_${idx + 1}_${Date.now()}`,
              type: 'true_false',
              topicId: primaryTopic.id,
              topicName: q.topicName || primaryTopic.name,
              lessonId: targetLesson.id,
              lessonName: q.lessonName || targetLesson.name,
              level: q.level || 'ThongHieu',
              learningOutcome: chosenOutcome,
              learningOutcomeIndex: outcomeIdx,
              diagramId: q.diagramId,
              content: q.content || 'Nội dung câu hỏi',
              statements: q.statements,
              solution: q.solution || 'Lời giải chi tiết.',
            };
          } else if (q.type === 'short_answer') {
            rawQ = {
              id: q.id || `gen_q_${idx + 1}_${Date.now()}`,
              type: 'short_answer',
              topicId: primaryTopic.id,
              topicName: q.topicName || primaryTopic.name,
              lessonId: targetLesson.id,
              lessonName: q.lessonName || targetLesson.name,
              level: q.level || 'ThongHieu',
              learningOutcome: chosenOutcome,
              learningOutcomeIndex: outcomeIdx,
              diagramId: q.diagramId,
              content: q.content || 'Nội dung câu hỏi',
              correctAnswer: q.correctAnswer || '1',
              solution: q.solution || 'Lời giải chi tiết.',
            };
          } else {
            rawQ = {
              id: q.id || `gen_q_${idx + 1}_${Date.now()}`,
              type: 'multiple_choice',
              topicId: primaryTopic.id,
              topicName: q.topicName || primaryTopic.name,
              lessonId: targetLesson.id,
              lessonName: q.lessonName || targetLesson.name,
              level: q.level || 'ThongHieu',
              learningOutcome: chosenOutcome,
              learningOutcomeIndex: outcomeIdx,
              diagramId: q.diagramId,
              content: q.content || 'Nội dung câu hỏi',
              options: q.options,
              correctAnswer: q.correctAnswer || 'A',
              solution: q.solution || 'Lời giải chi tiết.',
            };
          }

          return sanitizeQuestionMath(rawQ);
        });

        const alignedQuestions = alignQuestionsToOutcomeMatrix(newQuestions, testConfig);
        const finalQuestions = ensureUniqueDiagramsInTest(ensureUniqueQuestionIds(alignedQuestions));

        // Dynamically compute matrix and summary to ensure 100% precision match!
        const { matrix, summary } = calculateMatrixAndSummary(finalQuestions, testConfig);

        const updatedTest: GeneratedTest = {
          id: `test_ai_${Date.now()}`,
          createdAt: new Date().toISOString(),
          config: testConfig,
          questions: finalQuestions,
          matrix,
          summary,
        };

        setCurrentTest(updatedTest);
        setHasGenerated(true);
        handleAutoSaveNewTest(updatedTest);
      } else {
        const fallbackTest = createDefaultTest(testConfig);
        setCurrentTest(fallbackTest);
        setHasGenerated(true);
        handleAutoSaveNewTest(fallbackTest);
      }
    } catch (err) {
      console.error('Error generating questions:', err);
      const fallbackTest = createDefaultTest(testConfig);
      setCurrentTest(fallbackTest);
      setHasGenerated(true);
      handleAutoSaveNewTest(fallbackTest);
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate questions from pre-built Question Bank
  const handleGenerateFromBank = () => {
    setIsGenerating(true);
    setTimeout(() => {
      try {
        const bankTest = createDefaultTest(testConfig);
        setCurrentTest(bankTest);
        setHasGenerated(true);
        handleAutoSaveNewTest(bankTest);
      } catch (err) {
        console.error('Error generating from bank:', err);
        showNotification('❌ Có lỗi xảy ra khi tạo đề từ ngân hàng.');
      } finally {
        setIsGenerating(false);
      }
    }, 400);
  };

  const handleExportWord = async () => {
    if (!hasGenerated || !currentTest || currentTest.questions.length === 0) {
      showNotification('⚠️ Vui lòng tạo đề thi trước khi xuất file Word!');
      return;
    }
    try {
      await exportTestToWord(currentTest);
      showNotification('📄 Đã tải xuống file Word (.docx) chứa câu hỏi, đáp án và ma trận!');
    } catch (err) {
      console.error('Word export failed:', err);
      showNotification('❌ Có lỗi xảy ra khi xuất file Word.');
    }
  };

  const handleSaveQuestion = (updatedQ: Question) => {
    setCurrentTest((prev) => {
      const newQuestions = prev.questions.map((q) => (q.id === updatedQ.id ? updatedQ : q));
      const { matrix, summary } = calculateMatrixAndSummary(newQuestions, prev.config);
      return {
        ...prev,
        questions: newQuestions,
        matrix,
        summary,
      };
    });
    setEditingQuestion(null);
    showNotification('💾 Đã lưu thay đổi câu hỏi và cập nhật lại Ma trận.');
  };

  const handleDeleteQuestion = (id: string) => {
    setCurrentTest((prev) => {
      const filtered = prev.questions.filter((q) => q.id !== id);
      const { matrix, summary } = calculateMatrixAndSummary(filtered, prev.config);
      return {
        ...prev,
        questions: filtered,
        matrix,
        summary,
      };
    });
    showNotification('🗑️ Đã xóa câu hỏi khỏi bộ đề và cập nhật lại Ma trận.');
  };

  const handleDeleteSelectedQuestions = (idsToDelete: string[]) => {
    if (idsToDelete.length === 0) return;
    const idsSet = new Set(idsToDelete);
    setCurrentTest((prev) => {
      const filtered = prev.questions.filter((q) => !idsSet.has(q.id));
      const { matrix, summary } = calculateMatrixAndSummary(filtered, prev.config);
      return {
        ...prev,
        questions: filtered,
        matrix,
        summary,
      };
    });
    showNotification(`🗑️ Đã xóa thành công ${idsToDelete.length} câu hỏi đã chọn!`);
  };

  const handleApplyUniqueQuestions = (uniqueQuestions: Question[], removedCount: number) => {
    setCurrentTest((prev) => {
      const { matrix, summary } = calculateMatrixAndSummary(uniqueQuestions, prev.config);
      return {
        ...prev,
        questions: uniqueQuestions,
        matrix,
        summary,
      };
    });
    showNotification(`🎉 Đã lọc & loại bỏ ${removedCount} câu hỏi trùng lặp (≥80% nội dung)!`);
  };

  const handleImportQuestions = (importedQuestions: Question[], appendMode: boolean) => {
    setCurrentTest((prev) => {
      const combined = appendMode ? [...prev.questions, ...importedQuestions] : importedQuestions;
      const newQuestions = ensureUniqueDiagramsInTest(ensureUniqueQuestionIds(combined));
      const { matrix, summary } = calculateMatrixAndSummary(newQuestions, prev.config);
      return {
        ...prev,
        questions: newQuestions,
        matrix,
        summary,
      };
    });
    setHasGenerated(true);
    showNotification(`📥 Đã nạp ${importedQuestions.length} câu hỏi vào Ngân hàng câu hỏi!`);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Top Menu Bar */}
      <HeaderMenu
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportWord={handleExportWord}
        onGenerateNew={() => handleGenerateQuestions()}
        onOpenUpload={() => setIsUploadOpen(true)}
        onQuickSaveToBank={handleQuickSaveCurrentTest}
        isGenerating={isGenerating}
        questionCount={hasGenerated ? currentTest.questions.length : 0}
        savedCount={savedCount}
      />

      {/* Notification Toast */}
      {notification && (
        <div className="fixed top-16 right-4 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-blue-500/50 flex items-center space-x-2 text-xs animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold">{notification}</span>
        </div>
      )}

      {/* Main App Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 py-5">
        {/* Tab 1: Question Generator & Main Exam View */}
        {(activeTab === 'generator' || activeTab === 'editor') && (
          <div className="space-y-6">
            <QuestionGeneratorModal
              config={testConfig}
              setConfig={setTestConfig}
              onGenerate={handleGenerateQuestions}
              onGenerateFromBank={handleGenerateFromBank}
              isGenerating={isGenerating}
            />

            {hasGenerated && (
              <>
                <QuestionList
                  test={currentTest}
                  onEditQuestion={(q) => setEditingQuestion(q)}
                  onDeleteQuestion={handleDeleteQuestion}
                  onDeleteSelectedQuestions={handleDeleteSelectedQuestions}
                  onApplyUniqueQuestions={handleApplyUniqueQuestions}
                  onSaveToBank={handleQuickSaveCurrentTest}
                  onOpenBank={() => setActiveTab('bank')}
                />

                {/* Ma trận đề thi tự động tạo luôn nằm ngay bên dưới đề thi */}
                <div id="exam-matrix-section" className="pt-2">
                  <MatrixTable test={currentTest} />
                </div>
              </>
            )}
          </div>
        )}

        {/* Tab 2: Slide Presentation View */}
        {activeTab === 'slides' && (
          <div>
            {hasGenerated ? (
              <SlideViewer test={currentTest} />
            ) : (
              <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                <p className="text-sm text-slate-600 mb-3">Vui lòng tạo đề thi trước khi xem trình chiếu Slide.</p>
                <button
                  onClick={() => {
                    setActiveTab('generator');
                    handleGenerateQuestions();
                  }}
                  className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-lg"
                >
                  Tạo đề thi ngay
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Matrix View */}
        {activeTab === 'matrix' && (
          <div>
            {hasGenerated ? (
              <MatrixTable test={currentTest} />
            ) : (
              <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                <p className="text-sm text-slate-600 mb-3">Vui lòng tạo đề thi trước khi xem Bảng ma trận.</p>
                <button
                  onClick={() => {
                    setActiveTab('generator');
                    handleGenerateQuestions();
                  }}
                  className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-lg"
                >
                  Tạo đề thi ngay
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 5: Test Bank Repository View (Kho đề đã lưu với tên Khối-Lớp-Chủ đề) */}
        {activeTab === 'bank' && (
          <div>
            <TestBankModal
              currentTest={currentTest}
              onLoadTest={handleLoadTestFromBank}
              onSaveCurrentTest={handleQuickSaveCurrentTest}
            />
          </div>
        )}
      </main>

      {/* Edit Question Modal */}
      {editingQuestion && (
        <EditorModal
          question={editingQuestion}
          onSave={handleSaveQuestion}
          onClose={() => setEditingQuestion(null)}
        />
      )}

      {/* File Upload Modal (.doc, .docx, .pdf, .txt, .json) */}
      <FileUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onImportQuestions={handleImportQuestions}
      />

      {/* Floating AI Assistant Chat */}
      <AssistantChat
        currentTest={currentTest}
        onGenerateCommand={(cmd) => handleGenerateQuestions(cmd)}
        isGenerating={isGenerating}
      />

      {/* Duplicate Test Name Prompt Modal */}
      <DuplicatePromptModal
        isOpen={duplicatePromptState.isOpen}
        duplicateItem={duplicatePromptState.duplicateItem}
        proposedBaseFileName={duplicatePromptState.proposedBaseFileName}
        nextSequencedFileName={duplicatePromptState.nextSequencedFileName}
        onSaveAsNewVersion={handleConfirmSaveSequenced}
        onCancel={handleCancelDuplicatePrompt}
      />

      {/* Simple Footer with Author Credit */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-4 px-4 text-center text-xs">
        <p className="font-medium text-slate-300">
          TOÁN 12 — CHƯƠNG TRÌNH GDPT 2018
        </p>
        <p className="text-slate-500 mt-1">
          Tác giả: <strong className="text-emerald-400">NGUYỄN QUỐC TÂM</strong> • Trường THPT Mai Thanh Thế
        </p>
      </footer>
    </div>
  );
}
